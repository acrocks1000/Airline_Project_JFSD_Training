function notyet(){
     alert("This service is not available yet!");
}
